function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let tileSize = 60;

let rows = 5;

let cols = 5;

let farm = [];

let selectedTool = "seed"; // seed, water, harvest

let money = 100;

let seedCost = 10;

let harvestProfit = 25;

let growTime = 300; // frames (~5 segundos)

function setup() {
  createCanvas(cols * tileSize, rows * tileSize + 60);

  for (let i = 0; i < rows; i++) {
    farm[i] = [];

    for (let j = 0; j < cols; j++) {
      farm[i][j] = {
        state: "empty",

        watered: false,

        growCounter: 0,
      };
    }
  }

  frameRate(60);
}

function draw() {
  background(220);

  drawFarm();

  drawUI();

  updateGrowth();
}

function drawFarm() {
  for (let i = 0; i < rows; i++) {
    for (let j = 0; j < cols; j++) {
      let tile = farm[i][j];

      let x = j * tileSize;

      let y = i * tileSize;

      stroke(0);

      fill(getTileColor(tile));

      rect(x, y, tileSize, tileSize);
    }
  }
}

function drawUI() {
  fill(255);

  rect(0, rows * tileSize, width, 60);

  fill(0);

  textSize(16);

  text(
    `Ferramenta: ${selectedTool} | Dinheiro: $${money}`,
    10,
    rows * tileSize + 20
  );

  text(
    "1: Plantar ($10) | 2: Regar | 3: Colher (+$25)",
    10,
    rows * tileSize + 40
  );
}

function getTileColor(tile) {
  if (tile.state === "empty") return color(139, 69, 19);

  if (tile.state === "planted")
    return tile.watered ? color(100, 200, 100) : color(34, 139, 34);

  if (tile.state === "ready") return color(255, 215, 0);
}

function keyPressed() {
  if (key === "1") selectedTool = "seed";

  if (key === "2") selectedTool = "water";

  if (key === "3") selectedTool = "harvest";
}

function mousePressed() {
  if (mouseY > rows * tileSize) return;

  let i = floor(mouseY / tileSize);

  let j = floor(mouseX / tileSize);

  let tile = farm[i][j];

  if (selectedTool === "seed" && tile.state === "empty" && money >= seedCost) {
    tile.state = "planted";

    tile.watered = false;

    tile.growCounter = 0;

    money -= seedCost;
  } else if (selectedTool === "water" && tile.state === "planted") {
    tile.watered = true;
  } else if (selectedTool === "harvest" && tile.state === "ready") {
    tile.state = "empty";

    tile.watered = false;

    tile.growCounter = 0;

    money += harvestProfit;
  }
}

function updateGrowth() {
  for (let i = 0; i < rows; i++) {
    for (let j = 0; j < cols; j++) {
      let tile = farm[i][j];

      if (tile.state === "planted" && tile.watered) {
        tile.growCounter++;

        if (tile.growCounter >= growTime) {
          tile.state = "ready";
        }
      }
    }
  }
}
